package com.Hokkaido.GestorDeVentasApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestorDeVentasAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestorDeVentasAppApplication.class, args);
	}

}
