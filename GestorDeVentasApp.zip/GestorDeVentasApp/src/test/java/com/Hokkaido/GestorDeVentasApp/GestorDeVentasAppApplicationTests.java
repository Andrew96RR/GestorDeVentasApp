package com.Hokkaido.GestorDeVentasApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorDeVentasAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
