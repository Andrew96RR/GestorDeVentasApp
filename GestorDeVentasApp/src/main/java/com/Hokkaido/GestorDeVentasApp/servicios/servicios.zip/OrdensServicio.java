package com.Hokkaido.GestorDeVentasApp.servicios;

import java.util.List;

import com.Hokkaido.GestorDeVentasApp.entidades.Orders;

public interface OrdensServicio {
	
	List<Orders> getAllOrders();

}
