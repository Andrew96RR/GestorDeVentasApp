package com.Hokkaido.GestorDeVentasApp.servicios;

import java.util.List;

import com.Hokkaido.GestorDeVentasApp.entidades.Sales;

public interface SalesServicio {
	List<Sales> gitAllsales();

}
