package com.Hokkaido.GestorDeVentasApp.servicios;

import org.springframework.stereotype.Service;

@Service
public class Sales_prodServicioImpl implements Sales_prodServicio{
	

}
