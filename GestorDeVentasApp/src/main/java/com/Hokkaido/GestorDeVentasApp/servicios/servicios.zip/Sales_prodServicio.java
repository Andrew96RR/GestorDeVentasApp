package com.Hokkaido.GestorDeVentasApp.servicios;

public interface Sales_prodServicio {

}
